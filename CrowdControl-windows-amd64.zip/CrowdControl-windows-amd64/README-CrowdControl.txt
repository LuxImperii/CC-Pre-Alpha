CROWD CONTROL QUICK GUIDE

OBJECTIVE:

Protect the RED ZONE. Keep the area clear of people by defending it with guards, barricades, and patrol officers.

__

GAME LOOP:

This demo is 1 level comprised of 10 rounds.

During each round the simulation runs and all civilian units and player assets interact for 10 seconds.

At the end of each round, the simulation stops and you have the opportunity to place and remove assets. New assets may be made available to you at the end of the round, depending on your progress.

When civilian units move into the RED ZONE, your Score (shown at top right of screen) is reduced from its starting value of 1000. There is a penalty for each unit present, so the more civilians in the RED ZONE the faster your score goes down.

New civilians spawn each round - and will behave differently according to their unit type.

If your score reaches 0 you LOSE. If your score is above 0 at the end of the 10th round, you WIN.


After winning or losing, press ENTER again to restart the demo.

__

CONTROLS:

Assets may be deployed by pressing their corresponding key and placing them by clicking onscreen where you want them to deploy.

[P] = Patrol units: Click once for the start point of the Patrol path and a second time for the end point.

[B] = Barricades: press B again to rotate, and click to place

[G] = Guards: click to place Guards. You will see a Guards 'attention radius', these may overlap.

Assets may be erased (and returned to your deployment pool) by pressing [0](zero) 

Pressing ENTER begins the round and starts the timer.

__
